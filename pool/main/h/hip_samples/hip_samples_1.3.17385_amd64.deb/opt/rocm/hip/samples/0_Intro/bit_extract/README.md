# bit_extract

Show an application written directly in HIP which uses platform-specific check on __HIP_PLATFORM_HCC__ to enable use of 
an instruction that only exists on the HCC platform.

See related [blog](http://gpuopen.com/platform-aware-coding-inside-hip/) demonstrating platform specialization.
