var searchData=
[
  ['sgprallocgranule',['SGPRAllocGranule',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a59321d0e0a0c6f53e3e7f24b76540082',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]],
  ['sharedmemperblock',['sharedMemPerBlock',['../structhipDeviceProp__t.html#a3b9138678a0795c2677eddcfb1c67156',1,'hipDeviceProp_t']]]
];
