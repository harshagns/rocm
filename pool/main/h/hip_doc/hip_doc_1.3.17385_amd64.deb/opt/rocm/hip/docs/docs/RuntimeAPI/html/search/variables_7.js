var searchData=
[
  ['l2cachesize',['l2CacheSize',['../structhipDeviceProp__t.html#a24404decccc16833973c803ced6f3a51',1,'hipDeviceProp_t']]],
  ['localmemorysize',['LocalMemorySize',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a6fda5b747d4441a1db0843ae1fd830ad',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]]
];
