var searchData=
[
  ['gcnarch',['gcnArch',['../structhipDeviceProp__t.html#adc5950a3d5bbe00cf59d413d8aeeee18',1,'hipDeviceProp_t']]],
  ['global_20enum_20and_20defines',['Global enum and defines',['../group__GlobalDefs.html',1,'']]]
];
