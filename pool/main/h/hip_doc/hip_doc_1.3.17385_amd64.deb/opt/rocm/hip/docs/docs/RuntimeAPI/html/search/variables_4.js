var searchData=
[
  ['gcnarch',['gcnArch',['../structhipDeviceProp__t.html#adc5950a3d5bbe00cf59d413d8aeeee18',1,'hipDeviceProp_t']]]
];
