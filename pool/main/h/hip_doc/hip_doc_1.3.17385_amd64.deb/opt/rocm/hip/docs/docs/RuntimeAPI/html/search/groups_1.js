var searchData=
[
  ['device_20management',['Device Management',['../group__Device.html',1,'']]],
  ['device_20memory_20access',['Device Memory Access',['../group__PeerToPeer.html',1,'']]]
];
