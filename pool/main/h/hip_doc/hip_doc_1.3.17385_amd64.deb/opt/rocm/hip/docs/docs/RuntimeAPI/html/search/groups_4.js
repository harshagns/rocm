var searchData=
[
  ['global_20enum_20and_20defines',['Global enum and defines',['../group__GlobalDefs.html',1,'']]]
];
