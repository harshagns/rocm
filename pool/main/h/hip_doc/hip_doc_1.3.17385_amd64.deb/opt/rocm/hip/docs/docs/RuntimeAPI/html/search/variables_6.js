var searchData=
[
  ['ipc_5fhandle',['ipc_handle',['../classihipIpcMemHandle__t.html#af2142ab7d9f820acbad7638428509d42',1,'ihipIpcMemHandle_t']]],
  ['ismultigpuboard',['isMultiGpuBoard',['../structhipDeviceProp__t.html#a9bb19b2b0cdee8977ed63964532d639d',1,'hipDeviceProp_t']]]
];
