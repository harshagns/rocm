var searchData=
[
  ['fakemutex',['FakeMutex',['../classFakeMutex.html',1,'']]],
  ['fence_20functions',['Fence Functions',['../group__Fence.html',1,'']]],
  ['float1',['float1',['../structfloat1.html',1,'']]],
  ['float2',['float2',['../structfloat2.html',1,'']]],
  ['float3',['float3',['../structfloat3.html',1,'']]],
  ['float4',['float4',['../structfloat4.html',1,'']]],
  ['features',['features',['../group__HCC-specific.html',1,'']]]
];
