var searchData=
[
  ['dbname',['DbName',['../structDbName.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['device_20management',['Device Management',['../group__Device.html',1,'']]],
  ['dim3',['dim3',['../structdim3.html',1,'dim3'],['../group__GlobalDefs.html#gacb37281795c3567d0b10a61c056d512b',1,'dim3():&#160;hip_runtime_api.h']]],
  ['double1',['double1',['../structdouble1.html',1,'']]],
  ['double2',['double2',['../structdouble2.html',1,'']]],
  ['double3',['double3',['../structdouble3.html',1,'']]],
  ['double4',['double4',['../structdouble4.html',1,'']]],
  ['device_20memory_20access',['Device Memory Access',['../group__PeerToPeer.html',1,'']]]
];
