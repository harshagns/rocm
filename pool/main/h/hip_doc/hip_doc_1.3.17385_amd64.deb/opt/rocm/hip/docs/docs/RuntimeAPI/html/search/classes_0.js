var searchData=
[
  ['char1',['char1',['../structchar1.html',1,'']]],
  ['char2',['char2',['../structchar2.html',1,'']]],
  ['char3',['char3',['../structchar3.html',1,'']]],
  ['char4',['char4',['../structchar4.html',1,'']]]
];
