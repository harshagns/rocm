var searchData=
[
  ['canmaphostmemory',['canMapHostMemory',['../structhipDeviceProp__t.html#ac2143f5448607d1a02a9e8783fcf06a1',1,'hipDeviceProp_t']]],
  ['char1',['char1',['../structchar1.html',1,'']]],
  ['char2',['char2',['../structchar2.html',1,'']]],
  ['char3',['char3',['../structchar3.html',1,'']]],
  ['char4',['char4',['../structchar4.html',1,'']]],
  ['clockinstructionrate',['clockInstructionRate',['../structhipDeviceProp__t.html#a6fbf3b08a1a08ae700f1a06265f6666b',1,'hipDeviceProp_t']]],
  ['clockrate',['clockRate',['../structhipDeviceProp__t.html#a1dd15bee43692b8649dfbdc1adbaaf96',1,'hipDeviceProp_t']]],
  ['computemode',['computeMode',['../structhipDeviceProp__t.html#ae7d9216f8583a703359d0b9373823f5d',1,'hipDeviceProp_t']]],
  ['concurrentkernels',['concurrentKernels',['../structhipDeviceProp__t.html#ad8461a28caf9c38c58cf358583b5bee3',1,'hipDeviceProp_t']]],
  ['control',['Control',['../group__Profiler.html',1,'']]]
];
