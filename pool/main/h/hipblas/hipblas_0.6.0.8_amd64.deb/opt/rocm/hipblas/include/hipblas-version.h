/* ************************************************************************
 * Copyright 2016 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/* the configured version and settings
 */
#define hipblasVersionMajor 0
#define hipblaseVersionMinor 6
#define hipblasVersionPatch 0
#define hipblasVersionTweak 
